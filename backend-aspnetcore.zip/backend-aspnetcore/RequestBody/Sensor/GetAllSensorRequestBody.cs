namespace BackendAspNetCore.RequestBody.Sensor;

public class GetAllSensorRequestBody
{
    public int Limit { get; set; }
}