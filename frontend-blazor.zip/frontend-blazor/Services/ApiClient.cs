
using System.Net.Http.Json;

namespace FrontendBlazor.Services;

public class ApiClient
{
    private readonly HttpClient _http;
    private readonly string _base;

    public ApiClient(HttpClient http, IConfiguration cfg)
    {
        _http = http;
        _base = cfg["BackendBase"] ?? "https://localhost:5001";
    }

    public async Task<T?> GetJsonAsync<T>(string pathAndQuery)
        => await _http.GetFromJsonAsync<T>($"{_base.TrimEnd('/')}/{pathAndQuery.TrimStart('/')}");
}
